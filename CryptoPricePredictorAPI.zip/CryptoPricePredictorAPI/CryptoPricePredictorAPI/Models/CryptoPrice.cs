namespace CryptoPricePredictorAPI.Models
{
    public class CryptoPrice
    {
        public int Id { get; set; }
        public string? Symbol { get; set; } // Ahora puede ser nulo
        public decimal Price { get; set; }
        public DateTime Timestamp { get; set; }
    }

}



