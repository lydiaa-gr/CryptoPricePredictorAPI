using Microsoft.EntityFrameworkCore;
using CryptoPricePredictorAPI.Models;

namespace CryptoPricePredictorAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<CryptoPrice> CryptoPrices { get; set; }
    }
}






