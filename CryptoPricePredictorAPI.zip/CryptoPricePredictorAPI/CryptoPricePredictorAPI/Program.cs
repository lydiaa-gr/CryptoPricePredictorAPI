using Microsoft.EntityFrameworkCore;
using CryptoPricePredictorAPI.Data;

namespace CryptoPricePredictorAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Configuraci�n de la base de datos
            builder.Services.AddDbContext<AppDbContext>(options =>
               options.UseSqlServer(
                 builder.Configuration.GetConnectionString("DefaultConnection"),
                 sqlOptions => sqlOptions.EnableRetryOnFailure() // Para manejar errores transitorios
               )
            );

            // Habilitar CORS
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll", policy =>
                {
                    policy.AllowAnyOrigin()
                          .AllowAnyMethod()
                          .AllowAnyHeader();
                });
            });

            // Agregar servicios al contenedor
            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configuraci�n del entorno
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            // Usar la pol�tica de CORS
            app.UseCors("AllowAll");

            app.UseAuthorization();

            // Mapear controladores
            app.MapControllers();

            // Ruta base para verificar estado
            app.MapGet("/", () => "Crypto Price Predictor API is running!");

            app.Run();
        }
    }
}






