using Microsoft.AspNetCore.Mvc;
using CryptoPricePredictorAPI.Data;
using CryptoPricePredictorAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CryptoPricePredictorAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CryptoController : ControllerBase
    {
        private readonly AppDbContext _dbContext;

        public CryptoController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        // Endpoint para verificar el estado de la API
        [HttpGet("status")]
        public IActionResult GetStatus()
        {
            return Ok(new { status = "API is running", timestamp = DateTime.UtcNow });
        }

        // Endpoint para obtener todos los precios almacenados en la base de datos
        [HttpGet("prices")]
        public async Task<IActionResult> GetPrices()
        {
            try
            {
                var prices = await _dbContext.CryptoPrices.ToListAsync();
                return Ok(prices);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching prices.", details = ex.Message });
            }
        }

        // Endpoint para a�adir un nuevo precio
        [HttpPost("addPrice")]
        public async Task<IActionResult> AddPrice([FromBody] CryptoPrice price)
        {
            if (price == null || string.IsNullOrEmpty(price.Symbol) || price.Price <= 0)
            {
                return BadRequest(new { message = "Invalid price data." });
            }

            try
            {
                await _dbContext.CryptoPrices.AddAsync(price);
                await _dbContext.SaveChangesAsync();
                return Ok(new { message = "Price added successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while adding the price.", details = ex.Message });
            }
        }

        // Endpoint para obtener precios en vivo desde CoinGecko
        [HttpGet("livePrices")]
        public async Task<IActionResult> GetLivePrices()
        {
            try
            {
                using var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Add("User-Agent", "CryptoPricePredictorAPI"); // Importante para evitar errores 403
                var response = await httpClient.GetAsync("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false");

                if (!response.IsSuccessStatusCode)
                {
                    return StatusCode((int)response.StatusCode, new { message = "Failed to fetch live prices.", reason = response.ReasonPhrase });
                }

                var content = await response.Content.ReadAsStringAsync();
                return Ok(content); // Devuelve los datos en formato JSON
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while fetching live prices.", details = ex.Message });
            }
        }
    }
}












